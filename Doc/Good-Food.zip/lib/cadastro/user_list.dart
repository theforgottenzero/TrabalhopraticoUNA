import 'package:flutter/material.dart';

class Userlist extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Usoários'),
      ),
    );
  }
}