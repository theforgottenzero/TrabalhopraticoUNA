const DUMY_USER = {
  '1': const User (
    id: '1',
    nome: 'Choji',
    email: 'choji@alunos.com.br',
    peso: '127',
    altura: '1,60',
    sexo biologico: 'masculino',
    fotoUrl: 'https://i1.sndcdn.com/artworks-6zkLRGBsqEiMnRtE-plczvA-t500x500.jpg', 
  ),

  '2': const User (
    id: '2',
    nome: 'Sakura',
    email: 'sakura@alunos.com.br',
    peso: '80',
    altura: '1,70',
    sexo biologico: 'feminino',
    fotoUrl: 'https://sm.ign.com/ign_br/screenshot/default/naruto-sakura_2mx8.jpg',
  ),

  '3': const User (
    id: '3',
    nome: 'Naruto',
    email: 'naruto@alunos.com.br',
    peso: '85',
    altura: '1,80',
    sexo biologico: 'masculino',
    fotoUrl: 'https://pbs.twimg.com/profile_images/640663969301176320/syrXCE87_400x400.jpg',
  ),
  
}